package assignment1

import kotlin.collections.reversed as reversed1

fun main() {
    var str: String? = "Welcome to Kotlin"
    if (str != null) {
        var temp: String = str.toString()
        print(str.reversed())

    }
}