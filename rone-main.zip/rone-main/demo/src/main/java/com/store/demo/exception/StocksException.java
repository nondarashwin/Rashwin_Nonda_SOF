package com.store.demo.exception;

public class StocksException extends RuntimeException {
    public StocksException(String message) {
        super(message);
    }
}
