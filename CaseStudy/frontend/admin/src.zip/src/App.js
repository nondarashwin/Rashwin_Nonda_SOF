import logo from './logo.svg';
import './App.css';
import Product from "./Product";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import React, {Component} from "react";
import Store from "./Store";
class App extends Component{
    state={
        addProduct:true,
        addStore:false,
        Products:[{id:1,name:"Laptop",type:"Electonics",info:"8GB RAM,Intel I3",cost:330000,continuity:true},
            {id:2,name:"Mobile",type:"Electonics",info:"8GB RAM,128GB Memory",cost:78000,continuity:false},{id:3,name:"trimmer",type:"Electonics",info:"8 hours back up",cost:7800,continuity:false}
        ],product:{id:1,name:"Laptop",type:"Electonics",info:"8GB RAM,Intel I3",cost:90}
    }
    handleEvent(event){
        let st=this.state
        if(event.target.name=="id"){
            st.product.id=event.target.value
        }
        if(event.target.name=="name"){
            st.product.name=event.target.value
        }
        if(event.target.name=="cost"){
            st.product.cost=event.target.value
        }
        if(event.target.name=="info"){
            st.product.info=event.target.value
        }
        if(event.target.name=="category"){
            st.product.category=event.target.value
        }
        this.setState(st)

    }
    addProduct(){

        //let addProduct=!this.state.addProduct
        let st=this.state
        st.addProduct=!st.addProduct
        //console.log(addProduct)
        this.setState(st)



    }
    handleSubmit(){
        let st=this.state
        const p=st.Products.concat(st.product)
        st.Products=p
        this.setState(st)
    }
    render(){
  return (

    <div className="App">

        <Router>
            <div>
                <nav>
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item active">
                            <Link className="nav-link" to="/">Home</Link>
                        </li>
                        <li className="nav-item active">
                            <Link className="nav-link" to="/Product">Product</Link>
                        </li>
                        <li className="nav-item active">
                            <Link className="nav-link" to="/Stores">Stores</Link>
                        </li>
                    </ul>
                </nav>

                {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
                <Switch>
                    <Route path="/Product">
                        <a
                        href="#" className="btn btn-primary" onClick={this.addProduct.bind(this)}>
                            <svg width="1em" height="1em" viewBox="0 0 16 16" className="bi bi-plus" fill="currentColor"
                                 xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                      d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                            </svg>
                        Add</a>
                        <form onSubmit={this.handleSubmit.bind(this)}>
                            <label>id</label><input type="text" name="id" value={this.state.product.id} id="id" onChange={this.handleEvent.bind(this)}/>
                            <label>name</label><input type="text" name="name" value={this.state.product.name} id="name" onChange={this.handleEvent.bind(this)}/>
                            <label>cost</label><input type="text" namee="cost" value={this.state.product.cost} id="cost" onChange={this.handleEvent.bind(this)}/>
                            <label>category</label><input type="text" name="category" value={this.state.product.type}id="category" onChange={this.handleEvent.bind(this)}/>
                            <label>info</label><input type="text" name="info" value={this.state.product.info}id="info" onChange={this.handleEvent.bind(this)}/>
                            <input type="submit" className="btn btn-primary" value="Submit"/>
                        </form>
                        <div className="row">
                            <Product Products={this.state.Products}/></div>
                    </Route>
                    <Route path="/Stores">
                        <div className="row">
                        <Store />
                        </div>
                    </Route>
                    <Route path="/">
                        <Home />
                    </Route>
                </Switch>
            </div>

        </Router>



    </div>
  );
}
}
function Home(){
    return <h2>Home</h2>
}



export default App;
